#ifndef C_ACTIONS
#define C_ACTIONS
#include "CMatchPrep.h"
#include "CTeam.h"
#include <stdlib.h>
#include <time.h>

class CActions : public CMatchPrep
{
protected:
	unsigned short randNum;
public:
	CActions();
	void FirstWhistle();
	unsigned short Shoot(CTeam& team1, CTeam& team2);
	unsigned short Pass();
	unsigned short SlideTackle();
	unsigned short StandTackle();
	unsigned short Dribble(CTeam& team1, CTeam& team2);
	unsigned short Crossing();
	unsigned short Penalty();
	unsigned short Heading();
	unsigned short YellowCard();
	unsigned short RedCard();
	unsigned short SaveByTheGK();
	unsigned short ClearFromTheLine();
	unsigned short ChanceOfSuccess();
	unsigned short PositionOfBall(); // is on deff side mid side att side
};
#endif