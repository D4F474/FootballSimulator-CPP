#include "CActions.h"
CActions::CActions()
{
	srand(time(NULL));
}

unsigned short CActions::ChanceOfSuccess()
{
	return rand() % 1 + 0;
}

unsigned short CActions::PositionOfBall()
{
	return rand() % 3 + 1;
	//1 deffend side 2 mid side 3 attackers side
}

void CActions::FirstWhistle()
{
	randNum = rand() % 1 + 0;
	if (randNum > 0)
	{
		Ball = randNum;
	}
}
unsigned short CActions::Shoot(CTeam& team1, CTeam& team2)
{
	randNum = rand() % 10 + 0; // choosing a player
	CPlayer* playerHomeTeam = nullptr;
	CPlayer* playerAwayTeam = nullptr;
	switch (Ball)
	{
	case 0:
		
		break;
	case 1:

		break;
	default:
		break;
	}
	return 0;
}
unsigned short CActions::Pass()
{
	randNum = rand() % 10 + 0; // choosing a player
	CPlayer* playerHomeTeam = nullptr;
	CPlayer* playerAwayTeam = nullptr;
	switch (Ball)
	{
	case 0:

		break;
	case 1:

		break;
	default:
		break;
	}
	return 0;
}
unsigned short CActions::SlideTackle()
{
	randNum = rand() % 10 + 0; // choosing a player
	CPlayer* playerHomeTeam = nullptr;
	CPlayer* playerAwayTeam = nullptr;
	switch (Ball)
	{
	case 0:

		break;
	case 1:

		break;
	default:
		break;
	}
	return 0;
}
unsigned short CActions::StandTackle()
{
	randNum = rand() % 10 + 0; // choosing a player
	CPlayer* playerHomeTeam = nullptr;
	CPlayer* playerAwayTeam = nullptr;
	switch (Ball)
	{
	case 0:

		break;
	case 1:

		break;
	default:
		break;
	}
	return 0;
}
unsigned short CActions::Dribble(CTeam& team1, CTeam& team2)
{
	randNum = rand() % 10 + 0; // choosing a player
	CPlayer* playerHomeTeam = nullptr;
	CPlayer* playerAwayTeam = nullptr;
	switch (Ball)
	{
		case 0:
			//dribble
			if (PositionOfBall() == 1) 
			{
				playerAwayTeam = team2.getDeffenderPlayer();
				// deffender vs deffenders
				if (randNum > 1 && randNum < 5)
				{
					playerHomeTeam = team1.getDeffenderPlayer();
					if ((0.5 * (playerHomeTeam->getPositionStats().getDribbling() + playerHomeTeam->getPositionStats().getBallControll() + playerHomeTeam->getPositionStats().getStrength()) /
						(playerAwayTeam->getPositionStats().getStandTackle() + playerAwayTeam->getPositionStats().getSlideTackle() + playerAwayTeam->getPositionStats().getStrength())) > ChanceOfSuccess())
					{
						std::cout << "Wonderful dribble by deffender: " << playerHomeTeam->getLastName();
					}
					else
					{
						Ball = 1;
						std::cout << "Great tackle by deffender";
						team1.getStats().incrementTackles();
					}
				}
				//Mid vs deffenders
				else if (randNum > 4 && randNum < 8)
				{
					//CM
					playerHomeTeam = team1.getMidPlayer();
					if ((0.5 * (playerHomeTeam->getPositionStats().getDribbling() + playerHomeTeam->getPositionStats().getBallControll() + playerHomeTeam->getPositionStats().getStrength()) /
					(playerAwayTeam->getPositionStats().getStandTackle() + playerAwayTeam->getPositionStats().getSlideTackle() + playerAwayTeam->getPositionStats().getStrength())) > ChanceOfSuccess())
					{
						std::cout << "Wonderful dribble by deffender: " << playerHomeTeam->getLastName();
					}
					else 
					{
						Ball = 1;
						std::cout << "Great tackle by deffender";
						team1.getStats().incrementTackles();
					}
				}
				else if (randNum > 7 && randNum < 10)
				{
					//Att vs deffender
					playerHomeTeam = team1.getAttacker();
					if ((0.5 * (playerHomeTeam->getPositionStats().getDribbling() + playerHomeTeam->getPositionStats().getBallControll() + playerHomeTeam->getPositionStats().getStrength()) /
						(playerAwayTeam->getPositionStats().getStandTackle() + playerAwayTeam->getPositionStats().getSlideTackle() + playerAwayTeam->getPositionStats().getStrength())) > ChanceOfSuccess())
					{
						std::cout << "Wonderful dribble by middfilder!: " << playerHomeTeam->getLastName();
					}
					else
					{
						Ball = 1;
						std::cout << "Great tackle by deffender";
						team1.getStats().incrementTackles();
					}
				}
				else if (randNum == 0)
				{

					//GK
				}
			}
			else if (PositionOfBall() == 2) 
				// mid side away team
			{
				playerAwayTeam = team2.getMidPlayer();
				//deffender vs mid
				if (randNum > 1 && randNum < 5)
				{
					playerHomeTeam = team1.getDeffenderPlayer();
					if ((0.5 * (playerHomeTeam->getPositionStats().getDribbling() + playerHomeTeam->getPositionStats().getBallControll() + playerHomeTeam->getPositionStats().getStrength()) /
						(playerAwayTeam->getPositionStats().getStandTackle() + playerAwayTeam->getPositionStats().getSlideTackle() + playerAwayTeam->getPositionStats().getStrength())) > ChanceOfSuccess())
					{
						std::cout << "Wonderful dribble by deffender: " << playerHomeTeam->getLastName();
					}
					else
					{
						Ball = 1;
					}
				}
				//mid vs mid
				else if (randNum > 4 && randNum < 8)
				{
					playerHomeTeam = team1.getMidPlayer();
					if ((0.5 * (playerHomeTeam->getPositionStats().getDribbling() + playerHomeTeam->getPositionStats().getBallControll() + playerHomeTeam->getPositionStats().getStrength()) /
						(playerAwayTeam->getPositionStats().getStandTackle() + playerAwayTeam->getPositionStats().getSlideTackle() + playerAwayTeam->getPositionStats().getStrength())) > ChanceOfSuccess())
					{
						std::cout << "Wonderful dribble by Midfilder: " << playerHomeTeam->getLastName();
					}
					else
					{
						Ball = 1;
					}
					//CM
				}
				//attackers vs mid
				else if (randNum > 7 && randNum < 10)
				{
					playerHomeTeam = team1.getAttacker();
					if ((0.5 * (playerHomeTeam->getPositionStats().getDribbling() + playerHomeTeam->getPositionStats().getBallControll() + playerHomeTeam->getPositionStats().getStrength()) /
						(playerAwayTeam->getPositionStats().getStandTackle() + playerAwayTeam->getPositionStats().getSlideTackle() + playerAwayTeam->getPositionStats().getStrength())) > ChanceOfSuccess())
					{
						std::cout << "Wonderful dribble by deffender: " << playerHomeTeam->getLastName();
					}
					else
					{
						Ball = 1;
					}
					//Att
				}
				else if (randNum == 0)
				{
					//GK
				}
			}
			else if (PositionOfBall() == 3) 
				//attack side away team
			{
					playerAwayTeam = team2.getAttacker();
				if (randNum > 1 && randNum < 5)
				{
					playerHomeTeam = team1.getDeffenderPlayer();

					if ((0.5 * (playerHomeTeam->getPositionStats().getDribbling() + playerHomeTeam->getPositionStats().getBallControll() + playerHomeTeam->getPositionStats().getStrength()) /
						(playerAwayTeam->getPositionStats().getStandTackle() + playerAwayTeam->getPositionStats().getSlideTackle() + playerAwayTeam->getPositionStats().getStrength())) > ChanceOfSuccess())
					{
						std::cout << "Wonderful dribble by deffender: " << playerHomeTeam->getLastName();
					}
					else
					{
						Ball = 1;
					}
				}
				else if (randNum > 4 && randNum < 8)
				{
					playerHomeTeam = team1.getMidPlayer();

					if ((0.5 * (playerHomeTeam->getPositionStats().getDribbling() + playerHomeTeam->getPositionStats().getBallControll() + playerHomeTeam->getPositionStats().getStrength()) /
						(playerAwayTeam->getPositionStats().getStandTackle() + playerAwayTeam->getPositionStats().getSlideTackle() + playerAwayTeam->getPositionStats().getStrength())) > ChanceOfSuccess())
					{
						std::cout << "Wonderful dribble by deffender: " << playerHomeTeam->getLastName();
					}
					else
					{
						Ball = 1;
					}
					//CM
				}
				else if (randNum > 7 && randNum < 10)
				{
					playerHomeTeam = team1.getAttacker();

					if ((0.5 * (playerHomeTeam->getPositionStats().getDribbling() + playerHomeTeam->getPositionStats().getBallControll() + playerHomeTeam->getPositionStats().getStrength()) /
						(playerAwayTeam->getPositionStats().getStandTackle() + playerAwayTeam->getPositionStats().getSlideTackle() + playerAwayTeam->getPositionStats().getStrength())) > ChanceOfSuccess())
					{
						std::cout << "Wonderful dribble by deffender: " << playerHomeTeam->getLastName();
					}
					else
					{
						Ball = 1;
					}
					//Att
				}
				else if (randNum == 0)
				{
					//GK
				}
			}
			break;
		case 1:
			//dribble
			if (PositionOfBall() == 1)
			{
					playerHomeTeam = team1.getDeffenderPlayer();
				// deffender vs deffenders
				if (randNum > 1 && randNum < 5)
				{
				playerAwayTeam = team2.getDeffenderPlayer();
					if ((0.5 * (playerAwayTeam->getPositionStats().getDribbling() + playerAwayTeam->getPositionStats().getBallControll() + playerAwayTeam->getPositionStats().getStrength()) /
						(playerHomeTeam->getPositionStats().getStandTackle() + playerHomeTeam->getPositionStats().getSlideTackle() + playerHomeTeam->getPositionStats().getStrength())) > ChanceOfSuccess())
					{
						std::cout << "Wonderful dribble by deffender: " << playerHomeTeam->getLastName();
					}
					else
					{
						Ball = 1;
						std::cout << "Great tackle by deffender";
						team1.getStats().incrementTackles();
					}
				}
				//Mid vs deffenders
				else if (randNum > 4 && randNum < 8)
				{
					//CM
					playerAwayTeam = team2.getDeffenderPlayer();
					if ((0.5 * (playerAwayTeam->getPositionStats().getDribbling() + playerAwayTeam->getPositionStats().getBallControll() + playerAwayTeam->getPositionStats().getStrength()) /
						(playerHomeTeam->getPositionStats().getStandTackle() + playerHomeTeam->getPositionStats().getSlideTackle() + playerHomeTeam->getPositionStats().getStrength())) > ChanceOfSuccess())
					{
						std::cout << "Wonderful dribble by deffender: " << playerHomeTeam->getLastName();
					}
					else
					{
						Ball = 1;
						std::cout << "Great tackle by deffender";
						team1.getStats().incrementTackles();
					}
				}
				else if (randNum > 7 && randNum < 10)
				{
					//Att vs deffender
					playerAwayTeam = team2.getDeffenderPlayer();
					if ((0.5 * (playerAwayTeam->getPositionStats().getDribbling() + playerAwayTeam->getPositionStats().getBallControll() + playerAwayTeam->getPositionStats().getStrength()) /
						(playerHomeTeam->getPositionStats().getStandTackle() + playerHomeTeam->getPositionStats().getSlideTackle() + playerHomeTeam->getPositionStats().getStrength())) > ChanceOfSuccess())
					{
						std::cout << "Wonderful dribble by middfilder!: " << playerHomeTeam->getLastName();
					}
					else
					{
						Ball = 1;
						std::cout << "Great tackle by deffender";
						team1.getStats().incrementTackles();
					}
				}
				else if (randNum == 0)
				{

					//GK
				}
			}
			else if (PositionOfBall() == 2)
				// mid side away team
			{
				playerAwayTeam = team2.getDeffenderPlayer();
				//deffender vs mid
				if (randNum > 1 && randNum < 5)
				{
					playerHomeTeam = team1.getDeffenderPlayer();
					if ((0.5 * (playerAwayTeam->getPositionStats().getDribbling() + playerAwayTeam->getPositionStats().getBallControll() + playerAwayTeam->getPositionStats().getStrength()) /
						(playerHomeTeam->getPositionStats().getStandTackle() + playerHomeTeam->getPositionStats().getSlideTackle() + playerHomeTeam->getPositionStats().getStrength())) > ChanceOfSuccess())
					{
						std::cout << "Wonderful dribble by deffender: " << playerHomeTeam->getLastName();
					}
					else
					{
						Ball = 1;
					}
				}
				//mid vs mid
				else if (randNum > 4 && randNum < 8)
				{
					playerAwayTeam = team2.getDeffenderPlayer();
					if ((0.5 * (playerAwayTeam->getPositionStats().getDribbling() + playerAwayTeam->getPositionStats().getBallControll() + playerAwayTeam->getPositionStats().getStrength()) /
						(playerHomeTeam->getPositionStats().getStandTackle() + playerHomeTeam->getPositionStats().getSlideTackle() + playerHomeTeam->getPositionStats().getStrength())) > ChanceOfSuccess())
					{
						std::cout << "Wonderful dribble by Midfilder: " << playerHomeTeam->getLastName();
					}
					else
					{
						Ball = 1;
					}
					//CM
				}
				//attackers vs mid
				else if (randNum > 7 && randNum < 10)
				{
					playerAwayTeam = team2.getDeffenderPlayer();
					if ((0.5 * (playerAwayTeam->getPositionStats().getDribbling() + playerAwayTeam->getPositionStats().getBallControll() + playerAwayTeam->getPositionStats().getStrength()) /
						(playerHomeTeam->getPositionStats().getStandTackle() + playerHomeTeam->getPositionStats().getSlideTackle() + playerHomeTeam->getPositionStats().getStrength())) > ChanceOfSuccess())
					{
						std::cout << "Wonderful dribble by deffender: " << playerHomeTeam->getLastName();
					}
					else
					{
						Ball = 1;
					}
					//Att
				}
				else if (randNum == 0)
				{
					//GK
				}
			}
			else if (PositionOfBall() == 3)
				//attack side away team
			{
					playerHomeTeam = team1.getAttacker();
				if (randNum > 1 && randNum < 5)
				{
				playerAwayTeam = team2.getDeffenderPlayer();

					if ((0.5 * (playerAwayTeam->getPositionStats().getDribbling() + playerAwayTeam->getPositionStats().getBallControll() + playerAwayTeam->getPositionStats().getStrength()) /
						(playerHomeTeam->getPositionStats().getStandTackle() + playerHomeTeam->getPositionStats().getSlideTackle() + playerHomeTeam->getPositionStats().getStrength())) > ChanceOfSuccess())
					{
						std::cout << "Wonderful dribble by deffender: " << playerHomeTeam->getLastName();
					}
					else
					{
						Ball = 1;
					}
				}
				else if (randNum > 4 && randNum < 8)
				{
					playerAwayTeam = team2.getMidPlayer();

					if ((0.5 * (playerAwayTeam->getPositionStats().getDribbling() + playerAwayTeam->getPositionStats().getBallControll() + playerAwayTeam->getPositionStats().getStrength()) /
						(playerHomeTeam->getPositionStats().getStandTackle() + playerHomeTeam->getPositionStats().getSlideTackle() + playerHomeTeam->getPositionStats().getStrength())) > ChanceOfSuccess())
					{
						std::cout << "Wonderful dribble by deffender: " << playerHomeTeam->getLastName();
					}
					else
					{
						Ball = 1;
					}
					//CM
				}
				else if (randNum > 7 && randNum < 10)
				{
					playerAwayTeam = team2.getAttacker();

					if ((0.5 * (playerAwayTeam->getPositionStats().getDribbling() + playerAwayTeam->getPositionStats().getBallControll() + playerAwayTeam->getPositionStats().getStrength()) /
						(playerHomeTeam->getPositionStats().getStandTackle() + playerHomeTeam->getPositionStats().getSlideTackle() + playerHomeTeam->getPositionStats().getStrength())) > ChanceOfSuccess())
					{
						std::cout << "Wonderful dribble by deffender: " << playerHomeTeam->getLastName();
					}
					else
					{
						Ball = 1;
					}
					//Att
				}
				else if (randNum == 0)
				{
					//GK
				}
			}
			break;
			default:
				break;
	}
	return 0;
}
unsigned short CActions::Crossing()
{
	randNum = rand() % 10 + 0; // choosing a player
	CPlayer* playerHomeTeam = nullptr;
	CPlayer* playerAwayTeam = nullptr;
	switch (Ball)
	{
	case 0:

		break;
	case 1:

		break;
	default:
		break;
	}
	return 0;
}
unsigned short CActions::Penalty()
{
	randNum = rand() % 10 + 0; // choosing a player
	CPlayer* playerHomeTeam = nullptr;
	CPlayer* playerAwayTeam = nullptr;
	switch (Ball)
	{
	case 0:

		break;
	case 1:

		break;
	default:
		break;
	}
	return 0;
}
unsigned short CActions::Heading()
{
	randNum = rand() % 10 + 0; // choosing a player
	CPlayer* playerHomeTeam = nullptr;
	CPlayer* playerAwayTeam = nullptr;
	switch (Ball)
	{
	case 0:

		break;
	case 1:

		break;
	default:
		break;
	}
	return 0;
}
unsigned short CActions::YellowCard()
{
	randNum = rand() % 10 + 0; // choosing a player
	CPlayer* playerHomeTeam = nullptr;
	CPlayer* playerAwayTeam = nullptr;
	switch (Ball)
	{
	case 0:

		break;
	case 1:

		break;
	default:
		break;
	}
	return 0;
}
unsigned short CActions::RedCard()
{
	randNum = rand() % 10 + 0; // choosing a player
	CPlayer* playerHomeTeam = nullptr;
	CPlayer* playerAwayTeam = nullptr;
	switch (Ball)
	{
	case 0:

		break;
	case 1:

		break;
	default:
		break;
	}
	return 0;
}
unsigned short CActions::SaveByTheGK()
{
	randNum = rand() % 10 + 0; // choosing a player
	CPlayer* playerHomeTeam = nullptr;
	CPlayer* playerAwayTeam = nullptr;
	switch (Ball)
	{
	case 0:

		break;
	case 1:

		break;
	default:
		break;
	}
	return 0;
}
unsigned short CActions::ClearFromTheLine()
{
	randNum = rand() % 10 + 0; // choosing a player
	CPlayer* playerHomeTeam = nullptr;
	CPlayer* playerAwayTeam = nullptr;
	switch (Ball)
	{
	case 0:

		break;
	case 1:

		break;
	default:
		break;
	}
	return 0;
}