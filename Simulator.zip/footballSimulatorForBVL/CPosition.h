#ifndef C_Position
#define C_Position
#include <iostream>
#include "CAttackers.h"
#include "CDeffenders.h"
#include "CCentralMid.h"
#include "CGoalKeeper.h"
class CPosition 
{
	private:
		std::string POS;
		float ACCELERATION;
		float STAMINA;
		float STRENGTH;
		float SPRINT_SPEED;
		float VISION;
		float SLIDE_TACKLE;
		float STAND_TACKLE;
		float BALL_CONTROLL;
		float DRIBBLING;
		float CROSSING;
		float SHORT_PASS;
		float LONG_PASS;
		float HEADING;
		float SHOT_POWER;
		float LONG_SHOT;
		float PENALTIES;
		float FINISHING;
		float GK_POSSITIONING;
		float GK_DIVING;
		float GK_HANDLING;
		float GK_KICKING;
		float GK_REFLEXES;
		float OVR;
	public:
		CPosition(std::string pos, float acceleration, float stamina, float strength, float sprintSpeed,
			float vision, float slideTackle, float standTackle, float ballControll,
			float dribbling, float crossing, float shortPass, float longPass,
			float heading, float shotPower, float longShot, float penalties,
			float finishing, float GKPosstioning, float GKDiving, float GKHandling, float GKKicking, float Reflexes);
		
		float getAcceleration();
		float getStamina();
		float getStrength();
		float getSprintSpeed();
		float getVision();
		float getSlideTackle();
		float getStandTackle();
		float getBallControll();
		float getDribbling();
		float getCrossing();
		float getShortPass();
		float getLongPass();
		float getHeading();
		float getShotPower();
		float getLongShot();
		float getPenalties();
		float getFinishing();
		float getGKPossitioning();
		float getGKHandling();
		float getGKKicking();
		float getReflexes();
		float getOVR();

		friend std::ostream& operator << (std::ostream& toStream, const CPosition& stats);
};
#endif