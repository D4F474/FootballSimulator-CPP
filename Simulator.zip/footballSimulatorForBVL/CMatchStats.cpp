#include "CMatchStats.h"

void CMatchStats::incrementTackles()
{
	Tackles++;
}