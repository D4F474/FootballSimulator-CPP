#ifndef C_START_MATCH
#define C_START_MATCH

#include "CActions.h"
class CStartMatch : public CActions
{
public:
	void FirstWhistle();
};
#endif