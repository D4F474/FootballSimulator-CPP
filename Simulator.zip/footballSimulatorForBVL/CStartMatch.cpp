#include "CStartMatch.h"

void CStartMatch::FirstWhistle()
{
	while (true)
	{

	}
}